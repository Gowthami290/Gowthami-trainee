use MiniProjectRailway

create table Trains
(
trainid int primary key,
trainName varchar(20),
source varchar(20),
destination varchar(20),
availableBerths int,
trainClass varchar(20),
IsActive bit
)
select * from Trains

--drop table Trains
--drop table Bookingtickets

create table Bookingtickets
(
trainnumber int references Trains(trainid),
bokingId int identity(1,1),
passengername varchar(50),
class varchar(50),
Berths varchar(50),
)

Select * from Bookingtickets

create or alter proc BookingTickets (@tid int,@Passengername varchar(20),@class varchar(20),@nberths int)
as
begin
  
end